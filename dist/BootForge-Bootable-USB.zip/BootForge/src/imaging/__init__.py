"""Imaging utilities for BootForge."""

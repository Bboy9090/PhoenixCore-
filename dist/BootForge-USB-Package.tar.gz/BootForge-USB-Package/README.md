# BootForge USB Distribution Package

## Installation Instructions

### Linux
1. Copy this folder to your Linux system
2. Open terminal in this directory
3. Run: `chmod +x usb-installer.sh && ./usb-installer.sh`

### Windows
1. Copy this folder to your Windows system
2. Double-click `usb-installer.bat`
3. Follow the installation prompts

### macOS
1. Copy this folder to your Mac
2. Open Terminal in this directory
3. Run: `chmod +x usb-installer.sh && ./usb-installer.sh`

## What's Included

- BootForge-Linux-x64: Linux executable (ready to use)
- usb-installer.sh: Unix/Linux/macOS installer script
- usb-installer.bat: Windows installer script
- README.md: This file

## Cross-Platform Support

- Linux: ✅ Ready for immediate use
- Windows: ⏳ Executable coming soon (installer ready)
- macOS: ⏳ Executable coming soon (installer ready)

## Running BootForge

After installation:
- Linux/Windows: Run with `--gui` flag for graphical interface
- macOS: Use `open BootForge.app --args --gui`
- All platforms: Use `--help` to see CLI options

## System Requirements

- 64-bit operating system
- 2GB RAM minimum
- USB port for device operations
- Administrator/root privileges for USB access

For more information, visit: https://bootforge.dev
